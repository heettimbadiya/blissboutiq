import React from "react";
import CartPage from "../../components/cart/CartPage";

const Cart = () => {
  return (
    <>
      <CartPage />
    </>
  );
};

export default Cart;
